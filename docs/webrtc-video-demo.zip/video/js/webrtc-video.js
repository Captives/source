var trace = console.log;
(function () {
    var video = document.querySelector('#localVideo');
    var remoteVideo = document.querySelector('#remoteVideo');
    var options = {audio: true, video: {
        width: {exact: 254}, 
        height: {exact: 450}
    }};
    // var servers = {"iceServers": [{"urls": "stun:stun.l.google.com:19302"}]};
    var servers = null;

    //启动媒体设备
    navigator.mediaDevices.getUserMedia(options).then(function (stream) {
        window.localStream = stream;
        stream.oninactive = function () {
            trace('Stream inactive');
        };

        video.onloadedmetadata = function (e) {
            trace("Label: ", stream.label);
            trace("AudioTracks", stream.getAudioTracks());
            trace("VideoTracks", stream.getVideoTracks());
        };
        video.srcObject = stream;

        sendLocalStream();
    }).catch(function (error) {
        trace('navigator.getUserMedia error: ', error);
    });

    var localPeerConnection = null;
    var remotePeerConnection = null;
    //发送本地媒体流
    function sendLocalStream() {
        var audioTracks = window.localStream.getAudioTracks();
        var videoTracks = window.localStream.getVideoTracks();
        if (audioTracks.length > 0) {
            trace('Using audio device: ' + audioTracks[0].label);
        }
        if (videoTracks.length > 0) {
            trace('Using video device: ' + videoTracks[0].label);
        }
        //创建对等连接 RTCPeerConnection
        localPeerConnection = new RTCPeerConnection(servers);
        window.localStream.getTracks().forEach(function (track) {
            localPeerConnection.addTrack(track, window.localStream);
        });

        //创建数据通道
        var localChannel = localPeerConnection.createDataChannel('sendDataChannel');
        localChannel.onopen = localChannel.onclose = function (data) {
            var readyState = localChannel.readyState;
            trace('Send channel state is: ' + readyState);
        };

        localText.onkeyup = function (e) {
            localChannel.send(localText.value);
        };

        localPeerConnection.onicecandidate = function (event) {
            handleCandidate(event.candidate, remotePeerConnection, 'localPeer#:', 'local');
        };

        localPeerConnection.createOffer({
            offerToReceiveAudio: 1,
            offerToReceiveVideo: 1
        }).then(function (desc) {
            localPeerConnection.setLocalDescription(desc);
            trace('Offer from localPeerConnection \n' + desc.sdp);
            remotePeerConnection.setRemoteDescription(desc);

            remotePeerConnection.createAnswer().then(function (desc2) {
                remotePeerConnection.setLocalDescription(desc2);
                trace('Answer from remotePeerConnection \n' + desc2.sdp);
                localPeerConnection.setRemoteDescription(desc2);
            }).catch(function (error) {
                trace('Failed to create session description: ' + error.toString());
            });
        }).catch(function (error) {
            trace('Failed to create session description: ' + error.toString());
        });

        remotePeerConnection = new RTCPeerConnection(servers);
        remotePeerConnection.ontrack = remoteStreamsHandler;
        remotePeerConnection.onicecandidate = function (event) {
            handleCandidate(event.candidate, localPeerConnection, 'remotePeer#:', 'remote');
        };

        remotePeerConnection.ondatachannel = function (event) {
            var remoteChannel = event.channel;
            remoteChannel.onmessage = function (evt) {
                trace('Received Message');
                remoteText.value = evt.data;
            };

            remoteChannel.onopen = remoteChannel.onclose = function () {
                var readyState = remoteChannel.readyState;
                trace('Receive channel state is: ' + readyState);
            }
        };

        function handleCandidate(candidate, dest, prefix, type) {
            dest.addIceCandidate(candidate).then(function () {
                trace('AddIceCandidate success.');
            }).catch(function (error) {
                trace('Failed to add ICE candidate: ' + error.toString());
            });
            trace(prefix + 'New ' + type + ' ICE candidate: ' + (candidate ? candidate.candidate : '(null)'));
        }
    }

    function remoteStreamsHandler(evt) {
        remoteVideo.srcObject = evt.streams[0];
        trace('received remote stream', evt);
    }

    function hangup() {
        trace(' --- Ending calls ----');
        localPeerConnection.close();
        remotePeerConnection.close();
        localPeerConnection = null;
        remotePeerConnection = null;
    }

    /***********************************  聊天  *************************************/
    var localText = document.querySelector('textarea#localText');
    var remoteText = document.querySelector('textarea#remoteText');

    function addDataChannel() {

    }

    /***********************************  录制  *************************************/
    var recBtn = document.querySelector('#startRecord');
    var recordedVideo = document.querySelector('video#recordedVideo');
    recBtn.onclick = function (e) {
        if(recBtn.textContent == 'Record'){
            startRecording();
            recBtn.textContent = 'Stop';
            document.querySelector('#status').innerText = 'Rec...';
            recordedVideo.src = '';
        }else{
            stopRecording();
            playRecording();
            recBtn.textContent = 'Record';
            document.querySelector('#status').innerText = '';
        }
    };

    var mediaRecorder = null;
    var recordedBlobs = [];

    function startRecording() {
        recordedBlobs = [];
        var options = {mimeType: 'video/webm;codecs=vp9'};
        if (!MediaRecorder.isTypeSupported(options.mimeType)) {
            trace(options.mimeType + ' is not Supported');
            options = {mimeType: 'video/webm;codecs=vp8'};

            if (!MediaRecorder.isTypeSupported(options.mimeType)) {
                trace(options.mimeType + ' is not Supported');
                options = {mimeType: 'video/webm'};

                if (!MediaRecorder.isTypeSupported(options.mimeType)) {
                    trace(options.mimeType + ' is not Supported');
                    options = {mimeType: ''};
                }
            }
        }

        try {
            mediaRecorder = new MediaRecorder(window.localStream, options);
        } catch (e) {
            trace('Exception while creating MediaRecorder: ' + e);
            alert('Exception while creating MediaRecorder: '
                + e + '. mimeType: ' + options.mimeType);
            return;
        }

        trace('Created MediaRecorder', mediaRecorder, 'with options', options);
        mediaRecorder.onstop = function (event) {
            console.log('Recorder stopped: ', event);
        };

        mediaRecorder.ondataavailable = function (event) {
            if (event.data && event.data.size > 0) {
                recordedBlobs.push(event.data);
            }
        };

        mediaRecorder.start(10); // 数据收集10ms
        trace('MediaRecorder started', mediaRecorder);
    }

    function stopRecording() {
        mediaRecorder.stop();
        console.log('Recorded Blobs: ', recordedBlobs);
        recordedVideo.controls = true;
    }

    function playRecording(){
        var superBuffer = new Blob(recordedBlobs, {type: 'video/webm'});
        recordedVideo.src = window.URL.createObjectURL(superBuffer);
        // workaround for non-seekable video taken from
        // https://bugs.chromium.org/p/chromium/issues/detail?id=642012#c23
        recordedVideo.addEventListener('loadedmetadata', function() {
            if (recordedVideo.duration === Infinity) {
                recordedVideo.currentTime = 1e101;
                recordedVideo.ontimeupdate = function() {
                    recordedVideo.currentTime = 0;
                    recordedVideo.ontimeupdate = function() {
                        delete recordedVideo.ontimeupdate;
                        recordedVideo.play();
                    };
                };
            }
        });
    }
})();